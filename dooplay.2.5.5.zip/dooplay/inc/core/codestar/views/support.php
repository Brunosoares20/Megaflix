<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly. ?>

<p>We are provide support forum for premium version users. You can join to support forum for submit any question after purchasing. Free version users support is limited on github.</p>

<p><a href="http://support.codestarthemes.com/" class="button" target="_blank" rel="nofollow"><i class="fas fa-life-ring"></i> Support Forum</a> -(or)- <a href="https://github.com/Codestar/codestar-framework/issues" class="button" target="_blank" rel="nofollow"><i class="fab fa-github"></i> Github</a></p>
